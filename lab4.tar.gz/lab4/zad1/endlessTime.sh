#!/bin/bash
while :
do
	echo $(date)
done