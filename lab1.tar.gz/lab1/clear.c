#include <stdio.h>
#include <string.h>

int main() {
    remove("../raport2.txt");
    remove("../raport3a.txt");
    remove("../raport3b.txt");
}